<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form action="pro.php" method="post" enctype="multipart/form-data" name="form1" id="form1">
 
 
      <label>
        <input type="checkbox" name="heart_failure1" value="heart failure" id="heart_failure_0" />
        Shortness of breath</label>
      <br />
      <label>
        <input type="checkbox" name="heart_failure2" value="heart failure" id="heart_failure_1" />
        Fatigue</label>
      <br />
      <label>
        <input type="checkbox" name="heart_failure3" value="heart failure" id="heart_failure_2" />
        Feet swelling, ankles swelling</label>
      <br />
      <label>
        <input type="checkbox" name="heart_failure4" value="heart failure" id="heart_failure_3" />
        Coughing</label>
      <br />
      <label>
        <input type="checkbox" name="heart_failure5" value="heart failure" id="heart_failure_4" />
        Increased fat around the middle</label>
      <br />
      
      <label>
        <input type="checkbox" name="stroke1" value="stroke" id="stroke_0" />
        Old age</label>
      <br />
      <label>
        <input type="checkbox" name="stroke2" value="stroke" id="stroke_1" />
        High blood pressure</label>
      <br />
      <label>
        <input type="checkbox" name="stroke3" value="stroke" id="stroke_2" />
        Diabetes</label>
      <br />
      <label>
        <input type="checkbox" name="stroke4" value="stroke" id="stroke_3" />
        High cholesterol intake</label>
      <br />
      <label>
        <input type="checkbox" name="stroke7" value="stroke" id="stroke_6" />
  Headache</label>
 <br />
 <label>
      <input type="checkbox" name="coronary_heart_disease1" value="coronary heart disease" id="coronary_heart_disease_0" /></label>
 <label>Tobacco smoking</label>
 <br /><label>
      <input type="checkbox" name="coronary_heart_disease2" value="coronary heart disease" id="coronary_heart_disease_1" />
      Family history</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease3" value="coronary heart disease" id="coronary_heart_disease_2" />
      Hypertension</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease4" value="coronary heart disease" id="coronary_heart_disease_3" />
      Obesity</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease5" value="coronary heart disease" id="coronary_heart_disease_4" />
      Diabetes</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease6" value="coronary heart disease" id="coronary_heart_disease_5" />
      Lack of exercise</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease7" value="coronary heart disease" id="coronary_heart_disease_6" />
      Stress</label><br /><label>
      <input type="checkbox" name="coronary_heart_disease8" value="coronary heart disease" id="coronary_heart_disease_7" />
      High alcohol consumption</label>
      <br />
     <label>
             <input type="checkbox" name="Cor_pulmonale1" value="Cor pulmonale" id="Cor_pulmonale_0" />
             Shortness of breath which occurs on exertion but when severe can occur at rest</label>
         <br /><label>
             <input type="checkbox" name="Cor_pulmonale2" value="Cor pulmonale" id="Cor_pulmonale_1" />
             Wheezing</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale3" value="Cor pulmonale" id="Cor_pulmonale_2" />
             Chronic wet cough</label></td>
       <br /><label>
             <input type="checkbox" name="Cor_pulmonale4" value="Cor pulmonale" id="Cor_pulmonale_3" />
             Swelling of the abdomen with fluid (ascites)</label>
         <br /><label>
             <input type="checkbox" name="Cor_pulmonale5" value="Cor pulmonale" id="Cor_pulmonale_4" />
             Swelling of the ankles and feet (pedal edema)</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale6" value="Cor pulmonale" id="Cor_pulmonale_5" />
             Enlargement or prominent neck and facial veins</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale7" value="Cor pulmonale" id="Cor_pulmonale_6" />
             Raised Jugular Venous Pulse (JVP)</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale8" value="Cor pulmonale" id="Cor_pulmonale_7" />
             Enlargement of the liver</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale9" value="Cor pulmonale" id="Cor_pulmonale_8" />
             Bluish discoloration of face</label> <br /><label>
             <input type="checkbox" name="Cor_pulmonale10" value="Cor pulmonale" id="Cor_pulmonale_9" />
             Presence of abnormal heart sounds</label>
  <br />

    <label>
      <input type="checkbox" name="cardiac_dysrhythmia" value="cardiac dysrhythmia" id="cardiac_dysrhythmia_0" />
      Abnormal awareness of heartbeat</label>
    <br />

<br />
      
      <input type="submit" name="button" id="button" value="Submit" />
      <br />
    
</form>
</body>
</html>