<!DOCTYPE html>
<html dir="ltr" lang="en-US"><head><!-- Created by Artisteer v4.0.0.58833 -->
    <meta charset="utf-8">
    <title>Heart Disease Diagnosis</title>
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">

    <!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <link rel="stylesheet" href="style.css" media="screen">
    <!--[if lte IE 7]><link rel="stylesheet" href="style.ie7.css" media="screen" /><![endif]-->
    <link rel="stylesheet" href="style.responsive.css" media="all">


    <script src="jquery.js"></script>
    <script src="script.js"></script>
    <script src="script.responsive.js"></script>
<meta name="description" content="Description">
<meta name="keywords" content="Keywords">



<style>
.art-content .art-postcontent-0 .layout-item-0 { border-top-width:2px;border-top-style:solid;border-top-color:#BDBDBD;margin-top: 5px;margin-bottom: 5px;  }
.art-content .art-postcontent-0 .layout-item-1 { padding-top: 0px;padding-right: 10px;padding-bottom: 0px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-2 { background: ; padding-top: 0px;padding-right: 10px;padding-bottom: 0px;padding-left: 10px;  }
.art-content .art-postcontent-0 .layout-item-3 { padding-right: 10px;padding-left: 10px;  }
.ie7 .post .layout-cell {border:none !important; padding:0 !important; }
.ie6 .post .layout-cell {border:none !important; padding:0 !important; }

.style1 {font-family: "Times New Roman", Times, serif}
.style1 {font-family: "Times New Roman", Times, serif}
#apDiv1 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: 91px;
	top: 45px;
}
.style2 {color: #FFFFFF}
#apDiv2 {
	position:absolute;
	width:200px;
	height:115px;
	z-index:1;
	left: 48px;
	top: 351px;
}
</style></head>
<body>
<div id="art-main">
<header class="art-header clearfix">


    <div class="art-shapes">
<h1 class="art-headline" data-left="2.51%">
    <a href="#">HEART DIS</a>EASE
</h1>
<h2 class="art-slogan" data-left="2.51%">Expert System</h2>

<div class="art-object0" data-left="100%">
  <div class="style2" id="apDiv1"></div>
</div>
<div class="art-object369268148" data-left="0%"></div>

            </div>

<nav class="art-nav clearfix">
    <div class="art-nav-inner">
    <ul class="art-hmenu">
    <li><a href="index.php">Home</a></li>
    <li><a href="contact.php">Contacts</a></li>
    <li><a href="#" class="active">Heart Information</a>
    <ul>
    <li><a href="Structure.php">Structure</a></li>
    <li><a href="Functions.php">Functions</a></li>
    <li><a href="Diseases.php">Diseases</a></li>
    <li><a href="Risk.php">Risk Factor</a></li>
    <li><a href="Symptom.php">Symptoms</a></li>
    <li><a href="Diagnosis.php">Diagnosis</a></li>
    </ul>
    </li>
    <li><a href="userlogin.php">User Login</a></li>
    <li><a href="registration.php">Registration</a></li>
    
    </ul> 
        </div>
    </nav>

                    
</header>
<div class="art-sheet clearfix">
            <div class="art-layout-wrapper clearfix">
                <div class="art-content-layout">
                    <div class="art-content-layout-row">
                        <div class="art-layout-cell art-content clearfix"><article class="art-post art-article">
                                
                                                
                <div class="art-postcontent art-postcontent-0 clearfix"><div class="art-content-layout">
    <div class="art-content-layout-row">
    <div class="art-layout-cell layout-item-1" style="width: 40%" >
         <p><img width="300" height="543" alt="" src="images/beatm.gif" class=""></p>

        <div id="apDiv2"></div>
    </div><div class="art-layout-cell layout-item-2" style="width: 60%" >

<h1 class="style1">STRUCTURE OF THE HEART</h1>
<span class="style1"><br/>
<br/>
</span>
<p  class="a style1">
The adult human heart has a mass of between 250 and 350 grams and is about the size of a fist.  It is located anterior to the vertebral column and posterior to the sternum. <br><br>
It is enclosed in a double-walled sac called the pericardium. The superficial part of this sac is called the fibrous pericardium. This sac protects the heart, anchors its surrounding structures, and prevents overfilling of the heart with blood.
 <br><br>
The outer wall of the human heart is composed of three layers. The outer layer is called the epicardium, or visceral pericardium since it is also the inner wall of the pericardium. The middle layer is called the myocardium and is composed of cardiac muscle which contracts. The inner layer is called the endocardium and is in contact with the blood that the heart pumps.  Also, it merges with the inner lining (endothelium) of blood vessels and covers heart valves. 
<br><br>
The human heart has four chambers, two superior atria and two inferior ventricles. The atria are the receiving chambers and the ventricles are the discharging chambers. The pathway of blood through the human heart consists of a pulmonary circuit  and a systemic circuit. Deoxygenated blood flows through the heart in one direction, entering through the superior vena cava into the right atrium and is pumped through the tricuspid valve into the right ventricle before being pumped out through the pulmonary valve to the pulmonary arteries into the lungs. It returns from the lungs through the pulmonary veins to the left atrium where it is pumped through the mitral valve into the left ventricle before leaving through the aortic valve to the aorta.  </p>  
    </div>
    </div>
</div>
<div class="art-content-layout-br layout-item-0">
</div><div class="art-content-layout">
    <div class="art-content-layout-row">

    </div>
</div>
</div>
                                
                </article></div>
                    </div>
                </div>
            </div>
    </div>
<footer class="art-footer clearfix">
  <div class="art-footer-inner">
<div class="art-content-layout">

</div>


  </div>
</footer>

</div>


</body></html>